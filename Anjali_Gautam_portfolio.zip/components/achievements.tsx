"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, Trophy, Users, BookOpen } from "lucide-react"

export function Achievements() {
  const achievements = [
    {
      category: "Academic",
      icon: <BookOpen className="h-5 w-5" />,
      items: [
        "GATE Qualified - Data Science and Artificial Intelligence (DA)",
        "NPTEL Certification - Theory of Computation",
        "NPTEL Certification - Data Structure and Algorithm using Java",
        "NPTEL Certification - Programming in Java",
      ],
    },
    {
      category: "Competitions",
      icon: <Trophy className="h-5 w-5" />,
      items: [
        "Google Girl Hackathon 2025 Participant",
        "1st Place in Video Editing - REC Bijnor",
        "State-Level Badminton Player - Represented AKTU",
      ],
    },
    {
      category: "Leadership",
      icon: <Users className="h-5 w-5" />,
      items: [
        "GDSC Core Team Member - REC Bijnor",
        "Startup-Cell (R.A.I.S.E.) Collaborator - REC Bijnor",
        "AI/ML Workshop Completion - IHFC, IIT Delhi",
      ],
    },
  ]

  return (
    <section id="achievements" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="container mx-auto">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12">Achievements & Recognition</h2>

          <div className="grid md:grid-cols-3 gap-8">
            {achievements.map((category) => (
              <Card key={category.category} className="border-primary/20 hover:border-primary/40 transition-colors">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-xl">
                    {category.icon}
                    {category.category}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {category.items.map((item, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <Award className="h-4 w-4 text-primary mt-1 flex-shrink-0" />
                      <span className="text-sm text-muted-foreground">{item}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <h3 className="text-xl font-semibold mb-4">Languages</h3>
            <div className="flex justify-center gap-4 flex-wrap">
              <Badge variant="secondary" className="text-sm">
                English (Fluent)
              </Badge>
              <Badge variant="secondary" className="text-sm">
                Hindi (Native)
              </Badge>
              <Badge variant="secondary" className="text-sm">
                Spanish (Basic)
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
