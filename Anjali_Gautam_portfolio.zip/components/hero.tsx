import { Button } from "@/components/ui/button"
import { Linkedin, Mail, Code, Globe, Download, Instagram } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-6xl font-bold text-foreground mb-6">
            Hi, I'm <span className="text-primary">Anjali Gautam</span>
          </h1>
          <p className="text-xl sm:text-2xl text-muted-foreground mb-8 font-medium">IT Student & Software Developer</p>
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
            Passionate about cybersecurity, AI/ML, and building innovative solutions. Currently pursuing B.Tech in
            Information Technology with hands-on experience in ethical hacking and machine learning.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Button size="lg" asChild>
              <Link href="#projects">View My Work</Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="#contact">Get In Touch</Link>
            </Button>
          </div>

          {/* Download Resume Section */}
          <div className="mb-12 p-6 bg-card/50 backdrop-blur-sm rounded-lg border border-primary/20">
            <h3 className="text-lg font-semibold mb-3">Download My Resume</h3>
            <p className="text-muted-foreground mb-4 text-sm">
              Get a detailed overview of my experience, skills, and achievements
            </p>
            <Button asChild className="gap-2">
              <Link
                href="https://drive.google.com/file/d/1YobxjLDZDqRsBprR_eh9S23xEFcuecSD/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Download className="h-4 w-4" />
                Download Resume (PDF)
              </Link>
            </Button>
          </div>

          <div className="flex justify-center space-x-6">
            <Link
              href="https://www.linkedin.com/in/anjali-gautam-6a72a1258/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Linkedin className="h-6 w-6" />
              <span className="sr-only">LinkedIn</span>
            </Link>
            <Link
              href="https://leetcode.com/u/mVApBkRWga/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Code className="h-6 w-6" />
              <span className="sr-only">LeetCode</span>
            </Link>
            <Link
              href="https://developers.google.com/profile/u/103207786752621180992"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Globe className="h-6 w-6" />
              <span className="sr-only">Google Developer Profile</span>
            </Link>
            <Link
              href="https://www.instagram.com/automobiliaz/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Instagram className="h-6 w-6" />
              <span className="sr-only">Instagram</span>
            </Link>
            <Link
              href="mailto:anjalijelly04@gmail.com"
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Mail className="h-6 w-6" />
              <span className="sr-only">Email</span>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
