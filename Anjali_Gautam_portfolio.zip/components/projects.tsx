import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github } from "lucide-react"
import Link from "next/link"

export function Projects() {
  const projects = [
    {
      title: "College Attendance Tracking Platform",
      description:
        "A mobile check-in system with real-time Firebase sync that eliminated manual attendance errors for 500+ students. Reduced faculty workload by 20 hours/month and improved accuracy to 99%.",
      image: "/projects/attendance-platform.png",
      technologies: ["Java", "Firebase", "Android Studio", "MySQL"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "EduJunction Website",
      description:
        "An educational platform with personalized recommendation engine matching students with mentors and courses. Features integrated webinar tools and has hosted 10+ workshops with 300+ participants.",
      image: "/projects/edujunction-website.png",
      technologies: ["JavaScript", "Node.js", "Bootstrap", "MySQL"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "YOLOv7 License Plate Recognition",
      description:
        "Trained YOLOv7 model on custom datasets achieving 92% accuracy in real-time license plate recognition. Optimized for Raspberry Pi deployment, reducing inference time by 30%.",
      image: "/projects/license-plate-recognition.png",
      technologies: ["Python", "YOLOv7", "Raspberry Pi", "OpenCV"],
      liveUrl: "#",
      githubUrl: "#",
    },
  ]

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
      <div className="container mx-auto">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12">Featured Projects</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project) => (
              <Card
                key={project.title}
                className="overflow-hidden border-primary/20 hover:border-primary/40 transition-all duration-300 hover:shadow-lg"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{project.title}</CardTitle>
                  <CardDescription>{project.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <Badge key={tech} variant="secondary">
                        {tech}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" asChild>
                      <Link href={project.liveUrl}>
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Live Demo
                      </Link>
                    </Button>
                    <Button variant="outline" size="sm" asChild>
                      <Link href={project.githubUrl}>
                        <Github className="h-4 w-4 mr-2" />
                        Code
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
