"use client"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Award, BookOpen, Briefcase, Trophy, Eye, X } from "lucide-react"

export function Certificates() {
  const [selectedCertificate, setSelectedCertificate] = useState<string | null>(null)

  useEffect(() => {
    if (selectedCertificate) {
      // Prevent body scroll when modal is open
      document.body.style.overflow = "hidden"
    } else {
      // Restore body scroll when modal is closed
      document.body.style.overflow = "unset"
    }

    // Cleanup function to restore scroll on component unmount
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [selectedCertificate])

  const certificateCategories = [
    {
      title: "Academic Certifications",
      icon: <BookOpen className="h-5 w-5" />,
      certificates: [
        {
          title: "GATE 2025 Qualified",
          issuer: "IIT Roorkee",
          subject: "Data Science & Artificial Intelligence",
          score: "Qualified (Rank: 16343)",
          date: "2025",
          image: "/certificates/gate-2025-result.jpg",
        },
        {
          title: "Theory of Computation",
          issuer: "NPTEL - IIT Kanpur",
          subject: "Computer Science Theory",
          score: "69%",
          date: "Jul-Sep 2024",
          image: "/certificates/nptel-theory-computation.jpg",
        },
        {
          title: "AI, Data Analytics and Research Synergies",
          issuer: "NIT Delhi & ABV-IIITM Gwalior",
          subject: "Business Insights & AI",
          score: "Completed",
          date: "May-June 2025",
          image: "/certificates/nit-delhi-workshop.jpg",
        },
        {
          title: "Data Visualisation: Empowering Business",
          issuer: "Tata (via Forage)",
          subject: "Business Intelligence",
          score: "Completed",
          date: "Dec 2024 - July 2025",
          image: "/certificates/tata-data-visualization.jpg",
        },
        {
          title: "Technology Job Simulation",
          issuer: "Deloitte (via Forage)",
          subject: "Coding & Development",
          score: "Completed",
          date: "July 2025",
          image: "/certificates/deloitte-technology.jpg",
        },
        {
          title: "Data Structure and Algorithms using Java",
          issuer: "NPTEL - IIT Kharagpur",
          subject: "DSA with Java",
          score: "58%",
          date: "Jul-Oct 2024",
          image: "/certificates/nptel-dsa-java.jpg",
        },
        {
          title: "Programming in Java",
          issuer: "NPTEL - IIT Kharagpur",
          subject: "Java Programming",
          score: "57%",
          date: "Jan-Apr 2023",
          image: "/certificates/nptel-java.jpg",
        },
      ],
    },
    {
      title: "Professional Experience",
      icon: <Briefcase className="h-5 w-5" />,
      certificates: [
        {
          title: "AI/ML Internship",
          issuer: "INNOVATE",
          subject: "YOLOv7 License Plate Detection",
          score: "Successfully Completed",
          date: "Feb-May 2025",
          image: "/certificates/innovate-aiml-internship.jpg",
        },
        {
          title: "Ethical Hacking & Penetration Testing",
          issuer: "C-DAC Noida",
          subject: "Cybersecurity Training",
          score: "Successfully Completed",
          date: "May-June 2024",
          image: "/certificates/cdac-ethical-hacking.jpg",
        },
      ],
    },
    {
      title: "Competitions & Events",
      icon: <Trophy className="h-5 w-5" />,
      certificates: [
        {
          title: "Google Girl Hackathon 2025",
          issuer: "Google India",
          subject: "Hackathon Participation",
          score: "Participant",
          date: "2025",
          image: "/certificates/google-hackathon.jpg",
        },
        {
          title: "AKTU Sports Certificates",
          issuer: "Dr. A.P.J. Abdul Kalam Technical University",
          subject: "Sports Competitions",
          score: "Multiple Events",
          date: "2023-2024",
          image: "/certificates/aktu-sports.jpg",
        },
      ],
    },
  ]

  const openCertificate = (image: string) => {
    setSelectedCertificate(image)
  }

  const closeCertificate = () => {
    setSelectedCertificate(null)
  }

  return (
    <section id="certificates" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
      <div className="container mx-auto">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12">Certificates & Achievements</h2>

          <div className="space-y-12">
            {certificateCategories.map((category) => (
              <div key={category.title}>
                <div className="flex items-center gap-3 mb-6">
                  {category.icon}
                  <h3 className="text-2xl font-semibold">{category.title}</h3>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {category.certificates.map((cert, index) => (
                    <Card
                      key={index}
                      className="border-primary/20 hover:border-primary/40 transition-all duration-300 hover:shadow-lg"
                    >
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <Award className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => openCertificate(cert.image)}
                          >
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">View certificate</span>
                          </Button>
                        </div>
                        <CardTitle className="text-lg leading-tight">{cert.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <p className="text-sm font-medium text-primary">{cert.issuer}</p>
                          <p className="text-sm text-muted-foreground">{cert.subject}</p>
                        </div>

                        <div className="flex justify-between items-center">
                          <Badge variant="secondary" className="text-xs">
                            {cert.score}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{cert.date}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Certificate Modal */}
      {selectedCertificate && (
        <div
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 cursor-pointer"
          onClick={closeCertificate}
        >
          <div className="relative max-w-4xl max-h-[90vh] w-full cursor-default" onClick={(e) => e.stopPropagation()}>
            <Button
              variant="ghost"
              size="icon"
              className="absolute -top-12 right-0 text-white hover:bg-white/20 z-10"
              onClick={closeCertificate}
            >
              <X className="h-6 w-6" />
            </Button>
            <img
              src={selectedCertificate || "/placeholder.svg"}
              alt="Certificate"
              className="w-full h-auto max-h-[90vh] object-contain rounded-lg shadow-2xl cursor-default"
              onError={(e) => {
                console.error("Image failed to load:", selectedCertificate)
                e.currentTarget.src = "/placeholder.svg?height=400&width=600&text=Certificate+Not+Found"
              }}
            />
          </div>
        </div>
      )}
    </section>
  )
}
