import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"
import Link from "next/link"

export function About() {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
      <div className="container mx-auto">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12">About Me</h2>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <img
                src="/images/profile.jpg"
                alt="Anjali Gautam - Profile Photo"
                className="rounded-lg shadow-lg w-full max-w-md mx-auto"
              />
            </div>

            <div className="space-y-6">
              <p className="text-lg text-muted-foreground">
                I'm a dedicated Information Technology student at{" "}
                <Link
                  href="https://aktu.ac.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  Dr. A.P.J. Abdul Kalam Technical University
                </Link>{" "}
                with a passion for cybersecurity and artificial intelligence. Through my internships at C-DAC and
                INNOVATE, I've gained hands-on experience in ethical hacking, forensic analysis, and machine learning
                model development.
              </p>

              <p className="text-lg text-muted-foreground">
                When I'm not coding or studying, you can find me playing badminton (I'm a state-level player!), learning
                Spanish on{" "}
                <Link
                  href="https://www.duolingo.com/profile/AnjaliJelly"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  Duolingo
                </Link>
                , or participating in hackathons. I believe in continuous learning and am always excited to take on new
                challenges in the tech world.
              </p>

              <Card className="border-primary/20">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Quick Facts</h3>
                  <ul className="space-y-2 text-muted-foreground mb-4">
                    <li>🎓 B.Tech IT Student (2022-2026)</li>
                    <li>💼 Cybersecurity & AI/ML Intern</li>
                    <li>🌍 Based in Mirzapur, Uttar Pradesh</li>
                    <li>🏸 State-Level Badminton Player</li>
                  </ul>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" asChild>
                      <Link href="https://aktu.ac.in/" target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        My University
                      </Link>
                    </Button>
                    <Button size="sm" variant="outline" asChild>
                      <Link href="https://stmarymirzapur.com/" target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        My School
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
